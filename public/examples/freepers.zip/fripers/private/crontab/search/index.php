<?php
/**
 *
 * Indeksacja wyszukiwarki
 *  skrypt powinien byc uruchomiony w crontab-ie co np 10 minut
 *  
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
ini_set('include_path', '../../../public_html/:'.ini_get('include_path')); //echo ini_get('include_path'); die();

// dodatkowe funkcje
require_once('engine/scripts/functions.php');

// tworzymy obiekt silnika z parametrem CRON
require_once('engine/engine.class.php');
$oEngine = new Engine('CRON');

ini_set('display_errors', 1);

Config::$bShowDebug = FALSE;

$oSearch = new SearchModel();
$oSearch->index();

// zakonczenie programu, czyszczenie pamieci
unset($oSearch, $oEngine); die();
?>
