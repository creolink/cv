<?php
/**
 *
 * Plik glowny aplikacji
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
// dodatkowe funkcje
require_once('engine/scripts/functions.php');

// tworzymy obiekt silnika
require_once('engine/engine.class.php');
$oEngine = new Engine('WWW');

// zakonczenie programu, czyszczenie pamieci
unset($oEngine); die();
?>
