<?php
/**
 *
 * BannersModel - model bannerow / reklam
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class BannersModel extends Model
{
    /*
    // Deklaracje pol klasy
    */

    
    public $aFiltrStatus = array(                                                    // filtr - status
            0 => array('status' => 0, 'name' => 'aktywne', 'is_active' => 1),
            1 => array('status' => 1, 'name' => 'wyłączone', 'is_active' => 0)
        );
    
    public $aFiltrPlaces = array(                                                    // filtr - miejsca
            'intro-small' => array('place' => 'intro-small', 'name' => 'intro małe'),
            'intro-big' => array('place' => 'intro-big', 'name' => 'intro duże')
        );

    public $iId = 0;                                                                 // id banera
    public $aIds = NULL;                                                             // tablica id-ow banerow
    public $iLngId = 0;                                                              // id jezyka, 0 - wszystkie jezyki
    public $sPlace = '';                                                             // miejsce na stronie
    public $bUnActive = FALSE;                                                       // czy pobierac banery nieaktywne, flaga: FALSE - tylko aktywne, TRUE - tak (wszystkie)
    public $bExpired = FALSE;                                                        // czy pobierac banery z zakonczona emisja, flaga: FALSE - nie, TRUE - tak (wszystkie)
    public $bStarted = FALSE;                                                        // czy pobierac banery z rozpoczeta emisja, flaga: FALSE - nie, TRUE - tak (wszystkie)
    public $sSortColumn = '';                                                        // kolumna do sortowania
    public $sSortOrder = '';                                                         // kolejnosc sortowania: asc / desc
    public $iPage = 0;                                                               // numer strony
    public $iLimit = 30;                                                             // stronicowanie rekordow, 0 - wszystkie
    public $sSearch = '';                                                            // wyszukiwanie
    public $bGetData = FALSE;                                                        // czy pobierac dane dodatkowe (do listy w CMS), flaga: FALSE - nie, TRUE - tak


    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {

    }
    
    public function __destruct() {}


    /*
    // Metody prywatne, protected
    */


    private function _fetch()
    {
        $iId = ((int)($this->iId));
        $aIds = ((array)($this->aIds));
        $iLngId = ((int)($this->iLngId));
        $sPlace = trim((string)($this->sPlace));
        $bUnActive = ((bool)($this->bUnActive));
        $bExpired = ((bool)($this->bExpired));
        $bStarted = ((bool)($this->bStarted));
        $sSortColumn = trim((string)($this->sSortColumn));
        $sSortOrder = trim((string)($this->sSortOrder));
        $iPage = ((int)($this->iPage)); if ($iPage <= 0) { $iPage = 0; }
        $iLimit = ((int)($this->iLimit));
        $sSearch = trim((string)($this->sSearch));
        $bGetData = ((bool)($this->bGetData));
        
        $sSort = '';
        
        switch($sSortOrder)
        {
            case 'asc':
                $sSortOrder = 'ASC';
                break;
            
            case 'desc':
            default:
                $sSortOrder = 'DESC';
                break;
        }
        
        switch($sSortColumn)
        {
            case 'id':
                $sSort = 'BnrId '.$sSortOrder;
                break;
            
            case 'lng':
                $sSort = 'b.languages_id '.$sSortOrder;
                break;
            
            case 'start':
                $sSort = 'b.start_date '.$sSortOrder;
                break;
            
            case 'expire':
                $sSort = 'b.expire_date '.$sSortOrder;
                break;
            
            case 'place':
                $sSort = 'BnrPlace '.$sSortOrder;
                break;
            
            case 'title':
                $sSort = 'BnrTitle '.$sSortOrder;
                break;
            
            case 'date':
                $sSort = 'b.creation_date '.$sSortOrder;
                break;

            default:
                $sSort = 'BnrOrder '.$sSortOrder;
                break;
        }
        
        $aParams = array();
        if ($iId > 0) { $aParams[] = $iId; }
        if (sizeof($aIds) > 0) { $aParams = array_merge($aParams, $aIds); }
        if (strlen($sPlace) > 0) { $aParams[] = $sPlace; }
        if ($iLngId > 0) { $aParams[] = $iLngId; }
        if ($bExpired == FALSE) { $aParams[] = time(); }
        if ($bStarted == FALSE) { $aParams[] = time(); }
        if (isset($sSearch) && strlen($sSearch) > 0)
        {
            $aParams[] = '%'.preg_replace('~\s+~', '', $sSearch).'%';
            $aParams[] = $sSearch;
        }
        
        $sQuery = "SELECT SQL_CALC_FOUND_ROWS"
            .(($bGetData) ? " b.languages_id AS BnrLngId, b.is_active AS BnrActive, b.start_date AS BnrDStart, b.expire_date AS BnrDExpire, b.creation_date AS BnrDCreated," : "")
            ." b.id AS BnrId, b.sort_order AS BnrOrder,"
            ." b.place AS BnrPlace,"
            ." b.title AS BnrTitle, b.url AS BnrUrl"
            ." FROM banners b"
            ." WHERE 1"
            .(($iId > 0) ? " && b.id = ?" : "")
            .((sizeof($aIds) > 0) ? " && b.id IN(".Db::arrayToQuestionmarks($aIds).")" : "")
            .((strlen($sPlace) > 0) ? " && b.place = ?" : "")
            .(($iLngId > 0) ? " && b.languages_id = ?" : "")
            .(($bUnActive == FALSE) ? " && b.is_active = 1" : "")
            .(($bExpired == FALSE) ? " && (b.expire_date = 0 || b.expire_date >= ?)" : "")
            .(($bStarted == FALSE) ? " && (b.start_date = 0 || b.start_date <= ?)" : "")
            .((isset($sSearch) && strlen($sSearch) > 0) ? " && (REPLACE(CONCAT(b.title,b.url), ' ', '') LIKE ? || b.id = ?)" : "")
            .(($iId == 0 && $sSort != '') ? " ORDER BY ".$sSort : "")
            .(($iId > 0) ? " LIMIT 1" : (($iLimit > 0) ? " LIMIT ".(($iPage > 0) ? ($iPage * $iLimit)."," : "").$iLimit : ""));
        
        if ($aList = Db::$FRDb->sqlAll($sQuery, $aParams, 'BnrId'))
        {
            $iTotal = Db::$FRDb->sqlOne("SELECT FOUND_ROWS()");

            foreach($aList as &$aData)
            {
                if ($bGetData == TRUE) // pobieramy dodatkowe dane tylko jesli potrzeba
                {
                    $aData['BnrLng'] = Dictionary::$aLangsId[$aData['BnrLngId']]['name'];
                    $aData['BnrDStartStr'] = Lib::prepareDate($aData['BnrDStart'], TRUE);
                    $aData['BnrDExpireStr'] = Lib::prepareDate($aData['BnrDExpire'], TRUE);
                    $aData['BnrDCreatedStr'] = Lib::prepareDate($aData['BnrDCreated']);

                    $aData['BnrPlaceName'] = $this->aFiltrPlaces[$aData['BnrPlace']]['name'];
                }

                $aData['BnrSrc'] = $this->_getImage('hb'.$aData['BnrId']);
            }
            
            if ($iId > 0)
            {
                $aKeys = array_keys($aList);
                $aData = $aList[$aKeys[0]];
                
                return ($aData);
            }
            
            return (array($iTotal, $aList));
        }
        
        return NULL;
    }
    
    private function _getImage($p_sName = '', $p_bReturn = TRUE)
    {
        $sName = trim((string)($p_sName));
        $bReturn = ((bool)($p_bReturn)); // wymus zwrocenie NULL jesli nie ma obrazka
        
        if (($aFileData = Lib::checkFile(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_FilesBImages, $sName)) && is_array($aFileData))
        {
            $sFileName = $sName.'.'.$aFileData[1];
            $sFilePath = Config::BASE_Banners;
        }
        else
        {
            if ($bReturn == FALSE) { return NULL; }
            
            $sFilePath = Config::BASE_Banners;
            $sFileName = 'zastepczy.png';
        }
        
        return ($sFilePath.$sFileName);
    }
    
    private function _delImg($p_sDestFile, $p_sDestPath = '')
    {
        $sDestFile = trim((string)($p_sDestFile));
        $sDestPath = trim((string)($p_sDestPath));
        
        $aTypes = array('png', 'jpg', 'gif');
        
        $sDestPath = Config::RealPath.Config::FOLDER_Site.Config::FOLDER_FilesBImages.$sDestPath;
        
        foreach($aTypes as $sType)
        {
            if (file_exists($sDestPath.$sDestFile.'.'.$sType))
            {
                unlink($sDestPath.$sDestFile.'.'.$sType);
            }
        }
    }
    
    private function _saveImage($p_aFile, $p_sDstFile)
    {
        $aFile = ((array)($p_aFile));
        $sDstFile = trim((string)($p_sDstFile));
        
        if (isset($aFile['tmp_name']))
        {
            $sPath = Config::RealPath.Config::FOLDER_Site.Config::FOLDER_FilesBImages;
            $sExt = '.'.Lib::getFileExtension($aFile['name']);
            
            // jesli nie ma katalogu, tworzymy go
            if (!is_dir($sPath)) { @mkdir($sPath, 0777, TRUE); }
            
            // kasujemy istniejacy plik
            $this->_delImg($sDstFile);
            
            move_uploaded_file($aFile['tmp_name'], $sPath.$sDstFile.$sExt);
        }
    }

    private function _create(array $p_aData = NULL, $p_aFile = NULL)
    {
        $aData = ((array)($p_aData));
        $aFile = ((array)($p_aFile));
        
        $iDStart = 0;
        if (isset($aData['start_date']) && strlen($aData['start_date']) > 0 && ($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $aData['start_date'])))
        {
            $iDStart = strtotime($oDate->format('d.m.Y H:i:s'));
        }
        
        $iDExpire = 0;
        if (isset($aData['expire_date']) && strlen($aData['expire_date']) > 0 && ($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $aData['expire_date'])))
        {
            $iDExpire = strtotime($oDate->format('d.m.Y H:i:s'));
        }
        
        $sQuery = "INSERT INTO banners"
            ." ("
            ." is_active,"
            ." languages_id,"
            ." sort_order,"
            ." start_date, expire_date,"
            ." place,"
            ." title,"
            ." url,"
            ." creation_date"
            .")"
            ." VALUES"
            ." ("
            ." ?,"
            ." ?,"
            ." ?,"
            ." ?, ?,"
            ." ?,"
            ." ?,"
            ." ?,"
            ." UNIX_TIMESTAMP()"
            .")";
        
        $aParams = array();
        $aParams[] = ((isset($aData['is_active']) && $aData['is_active'] > 0) ? $aData['is_active'] : 0);
        $aParams[] = $aData['languages_id'];
        $aParams[] = ((isset($aData['sort_order']) && $aData['sort_order'] > 0) ? $aData['sort_order'] : 1);
        $aParams[] = $iDStart; $aParams[] = $iDExpire;
        $aParams[] = $aData['place'];
        $aParams[] = $aData['title'];
        $aParams[] = ((isset($aData['url']) && strlen($aData['url']) > 0) ? $aData['url'] : '');
        
        if (Db::$FRDb->sqlExec($sQuery, $aParams))
        {
            $iId = Db::$FRDb->sqlOne("SELECT LAST_INSERT_ID()");
            
            // wgrywamy obrazek
            if (isset($aFile)) { $this->_saveImage($aFile, 'hb'.$iId); }
            
            return ($iId);
        }
        
        return FALSE;
    }

    private function _update($p_iId = 0, array $p_aData = NULL, $p_aFile = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        $aFile = ((array)($p_aFile));
        
        if ($iId > 0)
        {
            $iDStart = 0;
            if (isset($aData['start_date']) && strlen($aData['start_date']) > 0 && ($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $aData['start_date'])))
            {
                $iDStart = strtotime($oDate->format('d.m.Y H:i:s'));
            }

            $iDExpire = 0;
            if (isset($aData['expire_date']) && strlen($aData['expire_date']) > 0 && ($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $aData['expire_date'])))
            {
                $iDExpire = strtotime($oDate->format('d.m.Y H:i:s'));
            }

            $sQuery = "UPDATE banners SET"
                ." is_active = ?,"
                ." languages_id = ?,"
                ." sort_order = ?,"
                ." start_date = ?, expire_date = ?,"
                ." place = ?,"
                ." title = ?,"
                ." url = ?"
                ." WHERE id = ?";

            $aParams = array();
            $aParams[] = ((isset($aData['is_active']) && $aData['is_active'] > 0) ? $aData['is_active'] : 0);
            $aParams[] = $aData['languages_id'];
            $aParams[] = ((isset($aData['sort_order']) && $aData['sort_order'] > 0) ? $aData['sort_order'] : 1);
            $aParams[] = $iDStart; $aParams[] = $iDExpire;
            $aParams[] = $aData['place'];
            $aParams[] = $aData['title'];
            $aParams[] = ((isset($aData['url']) && strlen($aData['url']) > 0) ? $aData['url'] : '');
            $aParams[] = $iId;
            
            Db::$FRDb->sqlExec($sQuery, $aParams);

            // wgrywamy obrazek
            if (isset($aFile)) { $this->_saveImage($aFile, 'hb'.$iId); }
            
            return TRUE;
        }
        
        return FALSE;
    }
    

    /*
    // Metody publiczne
    */

    
    // metoda pobiera filtry do listy (CMS)
    public function readFilter($p_sFilter = '')
    {
        $sFilter = trim((string)($p_sFilter));
        
        // oprogramowujemy filtr
        if ($aFilter = explode('|', urldecode(base64_decode($sFilter))))
        {
            $iLng = ((isset($aFilter[0])) ? trim((string)($aFilter[0])) : '');
            $bUnActive = ((isset($aFilter[1])) ? ((int)($aFilter[1])) : '0');
            $sPlace = ((isset($aFilter[2])) ? trim((string)($aFilter[2])) : '');
            $sSearch = ((isset($aFilter[3])) ? trim((string)($aFilter[3])) : '');
            
            $aResult = array(
                'lang' => $iLng,
                'unactive' => $bUnActive,
                'place' => $sPlace,
                'search' => $sSearch
            );
            
            return ($aResult);
        }
        
        return NULL;
    }
    
    // metoda pobiera dane / liste na podstawie pol klasy
    public function get()
    {
        return($this->_fetch());
    }
    
    // metoda pobiera banery wg podanego miejsca
    public function getPlace($p_sPlace = '', $p_iLngId = 0, $p_iLimit = 1)
    {
        $this->sPlace = trim((string)($p_sPlace));
        $this->iLngId = ((int)($p_iLngId));
        $this->iLimit = ((int)($p_iLimit));

        $aList = array();
        
        if ($aResult = $this->get())
        {
            if (is_array($aResult) && sizeof($aResult) > 0 && $aResult[0] > 0)
            {
                foreach($aResult[1] as $iBnrId => $aBnrData)
                {
                    $aList[$aBnrData['BnrPlace']][$iBnrId] = $aBnrData;
                }
            }
        }
        
        if (isset($aList[$this->sPlace]))
        {
            return($aList[$this->sPlace]);
        }
        
        return NULL;
    }
    
    // metoda waliduje przeslane dane w formularzu
    public function validate($p_iId = 0, $p_iLng, $p_sTitle, $p_sPlace, $p_sDStart, $p_sDExpire, $p_aImage)
    {
        $iId = ((int)($p_iId)); // id banera
        $iLng = ((int)($p_iLng)); // jezyk
        $sTitle = trim((string)($p_sTitle));
        $sPlace = trim((string)($p_sPlace));
        $sDStart = trim((string)($p_sDStart));
        $sDExpire = trim((string)($p_sDExpire));
        $aImage = ((array)($p_aImage));
        
        // tytul musi byc wpisany
        if (!$sTitle)
        {
            Error::set('ErrorTitle', 'Wpisz tytuł.');
        }
        
        // jezyk musi byc
        if (!$iLng || !isset(Dictionary::$aLangsId[$iLng]))
        {
            Error::set('ErrorLng', 'Wybierz język.');
        }
        
        // miejsce musi byc wybrane
        if (!$sPlace || !array_key_exists($sPlace, $this->aFiltrPlaces))
        {
            Error::set('ErrorPlace', 'Wybierz miejsce.');
        }
        
        // walidujemy daty
        $iDStart = $iDExpire = 0;
        if ($sDStart && (!($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $sDStart)) || !($iDStart = strtotime($oDate->format('d.m.Y H:i:s')))))
        {
            Error::set('ErrorDStart', 'Wpisz prawidłowo datę i godzinę lub zostaw pole puste.');
        }
        
        if ($sDExpire && (!($oDate = DateTime::createFromFormat('d/m/Y H:i:s', $sDExpire)) || !($iDExpire = strtotime($oDate->format('d.m.Y H:i:s')))))
        {
            Error::set('ErrorDExpire', 'Wpisz prawidłowo datę i godzinę lub zostaw pole puste.');
        }
        
        // daty konca nie moze byc mniejsza od poczatku
        if ($iDStart > $iDExpire)
        {
            Error::set('ErrorDExpire', 'Data końca emisji nie może być wcześniejsza.');
        }
        
        // jesli nie ma id (nowy baner), to obrazek byc musi
        if (!$iId && !isset($aImage['type']))
        {
            Error::set('ErrorImage', 'Wybierz obrazek banera.');
        }
        
        // jesli jest wgrany obrazek, to musi byc image/jpeg,image/jpg,image/gif,image/png
        if (isset($aImage['type']) && !in_array($aImage['type'], array('image/jpeg', 'image/jpg', 'image/gif', 'image/png')))
        {
            Error::set('ErrorImage', 'Obrazek banera musi być plikiem .jpg, .gif lub .png!');
        }

        if (!Error::check())
        {
            return TRUE;
        }
        
        return FALSE;
    }
    
    // metoda zapisuje baner
    public function save($p_iId = 0, array $p_aData = NULL, $p_aFile = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        $aFile = ((array)($p_aFile));
        
        if ($iId > 0)
        {
            return ($this->_update($iId, $aData, $aFile));
        }
        else
        {
            return ($this->_create($aData, $aFile));
        }
        
        return FALSE;
    }
    
    // metoda wylacza baner
    public function delete($p_iId)
    {
        $iId = ((int)($p_iId));

        if ($iId > 0)
        {
            $sQuery = "UPDATE banners SET is_active = 0 WHERE id = ?";
            
            $aParams = array();
            $aParams[] = $iId;
            
            Db::$FRDb->sqlExec($sQuery, $aParams);

            return TRUE;
        }
        
        Error::set('ErrorDelBnn', 'Nie udało się wyłączyć banera!');
        
        return FALSE;
    }
}
?>
