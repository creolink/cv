<?php
/**
 *
 * AjaxModel - model ajaxa
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class AjaxModel extends Model
{
    /*
    // Deklaracje pol klasy
    */

    
    protected $_iMaxValues = 15;     // maksymalna liczba linii w json-ie

    public $sAction = '';            // akcja w kontrolerze


    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {

    }


    /*
    // Metody prywatne, protected
    */

    
    /*
    private function _fetch()
    {
        
    }
    */

    
    /*
    // Metody publiczne
    */

    
    public function read()
    {
        // akcja to ostatni parametr z adresu /../
        $this->sAction = Router::$aAddress[(sizeof(Router::$aAddress) - 1)]; 

        return ($this);
    }
    
    public function get($p_sStream = '', $p_aItems = NULL, $p_sMime = 'html', $p_sItemLabel = '', $p_sItemValue = '', $p_sItemKey = '')
    {
        $sStream = trim((string)($p_sStream));
        $aItems = ((array)($p_aItems));
        $sMime = trim((string)($p_sMime));
        $sItemLabel = trim((string)($p_sItemLabel));
        $sItemValue = trim((string)($p_sItemValue));
        $sItemKey = trim((string)($p_sItemKey));
        
        // przygotowujemy dane do wyswietlenia
        switch($sMime)
        {
            case 'json':
            default:
                $aResult = array();
                if (is_array($aItems) && sizeof($aItems) > 0)
                {
                    foreach ($aItems as $sKey => $sValue)
                    {
                        $sValue[$sItemLabel] = trim(preg_replace("~\\t~", '', $sValue[$sItemLabel]));
                        $sValue[$sItemValue] = trim(preg_replace("~\\t~", '', $sValue[$sItemValue]));
                        array_push($aResult, array("id" => $sValue[$sItemKey], "label" => $sValue[$sItemLabel], "value" => strip_tags($sValue[$sItemValue])));

                        if (count($aResult) > $this->_iMaxValues) { break; }
                    }

                    $sStream = Lib::arrayToJson($aResult);
                }
                break;

            case 'html':
            default:
                break;
        }

        // naglowki dla pliku
        $aFileData['Stream'] = trim($sStream);
        $aFileData['Headers']['Content-Type'] = Lib::getMimeContentType($sMime);
        $aFileData['Headers']['Content-Length'] = strlen($aFileData['Stream']);
        $aFileData['Headers']['Connection'] = 'keep-alive';
        $aFileData['Headers']['Expires'] = gmdate('D, d M Y H:i:s \G\M\T', (time() + 1800));

        // zwracamy dane
        return ($aFileData);
    }
}
?>
