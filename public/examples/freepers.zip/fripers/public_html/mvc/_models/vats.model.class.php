<?php
/**
 *
 * VatsModel - model obslugi vatow
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class VatsModel extends Model
{
    /*
    // Deklaracje pol klasy
    */
    
    public static $aData = array();                                                        // dane wybranego rekordu
    
    public $aFiltrStatus = array(                                                          // filtr - status
            0 => array('status' => 0, 'name' => 'tylko aktywne', 'is_archived' => 0),
            1 => array('status' => 1, 'name' => 'zarchiwizowane', 'is_archived' => 1),
            2 => array('status' => 2, 'name' => 'wszystkie', 'is_archived' => NULL)
        );
    
    public $iId = 0;                                                                       // id rekordu
    public $bActive = TRUE;                                                                // flaga aktywnej stawki: FALSE - nie, TRUE - tak
    public $sName = '';                                                                    // nazwa stawki
    public $iIdAdd = 0;                                                                    // dodatkowy id stawki VAT, ktory ma byc pobrany
    public $iPage = 0;                                                                     // numer strony
    public $iLimit = 0;                                                                    // limit stronicowania, 0 - wszystkie rekordy
    public $sSortColumn = '';                                                              // kolumna do sortowania
    public $sSortOrder = '';                                                               // kolejnosc sortowania: asc / desc
    public $sSearch = '';                                                                  // wyszukiwanie
    public $iLangId = 0;                                                                   // id jezyka, 0 - wszystkie jezyki
    

    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {

    }
    
    public function __destruct() {}


    /*
    // Metody prywatne, protected
    */


    private function _fetch()
    {
        $iId = ((int)($this->iId));
        $bActive = ((bool)($this->bActive));
        $sName = trim((string)($this->sName));
        $iIdAdd = ((int)($this->iIdAdd));
        $iPage = ((int)($this->iPage)); if ($iPage <= 0) { $iPage = 0; }
        $iLimit = ((int)($this->iLimit)); if ($iLimit < 0) { $iLimit = 0; }
        $sSortColumn = trim((string)($this->sSortColumn));
        $sSortOrder = trim((string)($this->sSortOrder));
        $sSearch = trim((string)($this->sSearch));
        
        $sSort = '';
        
        switch($sSortOrder)
        {
            case 'desc':
                $sSortOrder = 'DESC';
                break;
            
            case 'asc':
            default:
                $sSortOrder = 'ASC';
                break;
        }
        
        switch($sSortColumn)
        {
            case 'id':
                $sSort = 'VatId '.$sSortOrder;
                break;
            
            case 'active':
                $sSort = 'VatActive '.$sSortOrder.', id DESC';
                break;
            
            case 'default':
                $sSort = 'VatDefault '.$sSortOrder.', id DESC';
                break;
            
            case 'name':
                $sSort = 'VatName '.$sSortOrder.', id DESC';
                break;
            
            case 'value':
                $sSort = 'VatValue '.$sSortOrder.', id DESC';
                break;
            
            default:
                $sSort = '';
                break;
        }
        
        $aParams = array();
        if ($bActive && $iIdAdd > 0) { $aParams[] = $iIdAdd; }
        if ($iId > 0) { $aParams[] = $iId; }
        if (strlen($sName) > 0) { $aParams[] = $sName; }
        if (isset($sSearch) && strlen($sSearch) > 0)
        {
            $aParams[] = '%'.preg_replace('~\s+~', '', $sSearch).'%';
            $aParams[] = $sSearch;
        }
        
        $sQuery = "SELECT" // SQL_CALC_FOUND_ROWS
            ." id AS VatId, name AS VatName, value AS VatValue,"
            ." CONCAT(id,',',value) AS VatIdRate,"
            ." is_active AS VatActive, is_default AS VatDefault"    
            ." FROM vats"
            ." WHERE 1"
            .(($bActive) ? " && (is_active = TRUE".(($iIdAdd > 0) ? " || id = ?" : "").")" : "")
            .(($iId > 0) ? " && id = ?" : "")
            .((strlen($sName) > 0) ? " && name = ?" : "")
            .(($sSort != '') ? " ORDER BY ".$sSort : "")
            .(($iId > 0 || strlen($sName) > 0) ? " LIMIT 1" : (($iLimit > 0) ? " LIMIT ".(($iPage > 0) ? ($iPage * $iLimit)."," : "").$iLimit : ""));
        
        if($aList = Db::$FRDb->sqlAll($sQuery, $aParams, 'VatId'))
        {
            if ($iId > 0 || strlen($sName) > 0)
            {
                $aKeys = array_keys($aList);
                $aData = $aList[$aKeys[0]];
                return ($aData);
            }
            
            return ($aList);
        }

        return FALSE;
    }

    private function _create(array $p_aData = NULL)
    {
        $aData = ((array)($p_aData));
        
        $sQuery = "INSERT INTO vats"
            ." ("
            ." is_active,"
            ." is_default,"
            ." name,"
            ." value"
            .")"
            ." VALUES"
            ." ("
            ." ?,"
            ." ?,"
            ." ?,"
            ." ?"
            .")";
        
        $aParams = array();
        $aParams[] = ((isset($aData['is_active']) && $aData['is_active'] > 0) ? 1 : 0);
        $aParams[] = ((isset($aData['is_default']) && $aData['is_default'] > 0) ? 1 : 0);
        $aParams[] = $aData['name'];
        $aParams[] = ((isset($aData['value']) && $aData['value'] >= 0) ? $aData['value'] : 0);
        
        if (Db::$FRDb->sqlExec($sQuery, $aParams))
        {
            $iId = Db::$FRDb->sqlOne("SELECT LAST_INSERT_ID()");
            
            return ($iId);
        }
        
        return FALSE;
    }

    private function _update($p_iId = 0, array $p_aData = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        
        if ($iId > 0)
        {
            $sQuery = "UPDATE vats SET"
                ." is_active = ?,"
                ." is_default = ?,"
                ." name = ?,"
                ." value = ?"
                ." WHERE id = ?";

            $aParams = array();
            $aParams[] = ((isset($aData['is_active']) && $aData['is_active'] > 0) ? 1 : 0);
            $aParams[] = ((isset($aData['is_default']) && $aData['is_default'] > 0) ? 1 : 0);
            $aParams[] = $aData['name'];
            $aParams[] = ((isset($aData['value']) && $aData['value'] >= 0) ? $aData['value'] : 0);
            $aParams[] = $iId;
            
            Db::$FRDb->sqlExec($sQuery, $aParams);

            return TRUE;
        }
        
        return FALSE;
    }
    
    // metoda czysci domyslna stawke
    private function _clearDefault()
    {
        Db::$FRDb->sqlExec("UPDATE vats SET is_default = 0 WHERE 1");
    }
    

    /*
    // Metody publiczne
    */
    
    
    // metoda pobiera filtry do listy (CMS)
    public function readFilter($p_sFilter = '')
    {
        $sFilter = trim((string)($p_sFilter));
        
        // oprogramowujemy filtr
        if ($aFilter = explode('|', urldecode(base64_decode($sFilter))))
        {
            $sSearch = ((isset($aFilter[0])) ? trim((string)($aFilter[0])) : '');
            
            $aResult = array(
                'search' => $sSearch
            );
            
            return ($aResult);
        }
        
        return NULL;
    }
    
    public function get()
    {
        return $this->_fetch();
    }
    
    // metoda waliduje przeslane dane w formularzu
    public function validate($p_iId = 0, $p_iValue, $p_sName)
    {
        $iId = ((int)($p_iId)); // id stawki
        $iValue = ((int)($p_iValue)); // wartosc
        $sName = trim((string)($p_sName)); // nazwa
        
        // nazwa byc musi
        if (!$sName)
        {
            Error::set('ErrorName', 'Wpisz nazwę.');
        }
        
        // wartosc byc musi
        if ($iValue < 0)
        {
            Error::set('ErrorValue', 'Wpisz wartość większą lub równą zero.');
        }

        if (!Error::check())
        {
            return TRUE;
        }
        
        return FALSE;
    }
    
    // metoda zapisuje baner
    public function save($p_iId = 0, array $p_aData = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        
        // ustawiamy domyslna stawke
        if (isset($aData['is_default']) && $aData['is_default'] > 0) { $this->_clearDefault(); }
        
        if ($iId > 0)
        {
            return ($this->_update($iId, $aData));
        }
        else
        {
            return ($this->_create($aData));
        }
        
        return FALSE;
    }
    
    // metoda wylacza stawke z uzytku
    public function delete($p_iId)
    {
        $iId = ((int)($p_iId));

        if ($iId > 0)
        {
            $sQuery = "UPDATE vats SET is_active = 0 WHERE id = ?";
            
            $aParams = array();
            $aParams[] = $iId;
            
            Db::$FRDb->sqlExec($sQuery, $aParams);

            return TRUE;
        }
        
        Error::set('ErrorDelVat', 'Nie udało się wyłączyć stawki VAT!');
        
        return FALSE;
    }
}
?>
