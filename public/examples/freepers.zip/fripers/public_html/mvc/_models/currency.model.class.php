<?php
/**
 *
 * CurrencyModel - model walut
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class CurrencyModel extends Model
{
    /*
    // Deklaracje pol klasy
    */


    public $iId = NULL;                                                                // id rekordu
    public $iLangId = 0;                                                               // id jezyka, 0 - wszystkie jezyki
    public $aIds = NULL;                                                               // tablica id-ow
    public $iPage = 0;                                                                 // numer strony
    public $iLimit = 0;                                                                // limit stronicowania, 0 - wszystkie rekordy
    public $sSortColumn = '';                                                          // kolumna do sortowania
    public $sSortOrder = '';                                                           // kolejnosc sortowania: asc / desc
    public $sSearch = '';                                                              // wyszukiwanie


    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {

    }
    
    public function __destruct() {}


    /*
    // Metody prywatne, protected
    */


    private function _fetch()
    {
        $iId = ((int)($this->iId));
        $iLangId = ((int)($this->iLangId));
        $aIds = ((array)($this->aIds));
        $iPage = ((int)($this->iPage)); if ($iPage <= 0) { $iPage = 0; }
        $iLimit = ((int)($this->iLimit)); if ($iLimit < 0) { $iLimit = 0; }
        $sSortColumn = trim((string)($this->sSortColumn));
        $sSortOrder = trim((string)($this->sSortOrder));
        $sSearch = trim((string)($this->sSearch));
        
        $sSort = '';
        
        switch($sSortOrder)
        {
            case 'desc':
                $sSortOrder = 'DESC';
                break;
            
            case 'asc':
            default:
                $sSortOrder = 'ASC';
                break;
        }
        
        switch($sSortColumn)
        {
            case 'id':
                $sSort = 'id '.$sSortOrder;
                break;
            
            case 'code':
                $sSort = 'CurrCode '.$sSortOrder.', id DESC';
                break;
            
            case 'name':
                $sSort = 'CurrTitle '.$sSortOrder.', id DESC';
                break;
            
            case 'symbol':
                $sSort = 'CurrSymbol '.$sSortOrder.', id DESC';
                break;
            
            case 'value':
                $sSort = 'CurrValue '.$sSortOrder.', id DESC';
                break;
            
            default:
                $sSort = 'CurrCode '.$sSortOrder;
                break;
        }
        
        $aParams = array();
        if ($iId > 0) { $aParams[] = $iId; }
        if (isset($sSearch) && strlen($sSearch) > 0)
        {
            $aParams[] = '%'.preg_replace('~\s+~', '', $sSearch).'%';
            $aParams[] = $sSearch;
        }
        
        $sQuery = "SELECT SQL_CALC_FOUND_ROWS"
            ." c.id AS CurrId,"
            ." c.title AS CurrTitle, c.code AS CurrCode,"
            ." c.symbol AS CurrSymbol,"
            ." c.value AS CurrValue, ROUND((1/c.value), 2) AS CurrPrice"
            ." FROM currencies c"
            ." WHERE 1"
            .(($iId > 0) ? " && id = ?" : "")
            .((isset($sSearch) && strlen($sSearch) > 0) ? " && (REPLACE(CONCAT(c.title,c.code,c.symbol), ' ', '') LIKE ? || c.id = ?)" : "")
            .(($sSort != '') ? " ORDER BY ".$sSort : "")
            .(($iLimit > 0) ? " LIMIT ".(($iPage > 0) ? ($iPage * $iLimit)."," : "").$iLimit : "");
        
        if ($aList = Db::$FRDb->sqlAll($sQuery, $aParams, 'CurrId'))
        {
            $iTotal = Db::$FRDb->sqlOne("SELECT FOUND_ROWS()");
            
            if ($iId > 0)
            {
                $aKeys = array_keys($aList);
                $aData = $aList[$aKeys[0]];
                
                return ($aData);
            }
            
            return (array($iTotal, $aList));
        }
        
        return NULL;
    }
    
    
    private function _create(array $p_aData = NULL) {}

    private function _update($p_iId = 0, array $p_aData = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        
        if ($iId > 0)
        {
            $sQuery = "UPDATE currencies SET"
                ." title = ?,"
                ." code = ?,"
                ." symbol = ?,"
                ." value = ?,"
                ." modification_date = UNIX_TIMESTAMP()"
                ." WHERE id = ?";

            $aParams = array();
            $aParams[] = $aData['title'];
            $aParams[] = $aData['code'];
            $aParams[] = html_entity_decode($aData['symbol']);
            $aParams[] = ((isset($aData['value']) && $aData['value'] > 0) ? $aData['value'] : 1);
            $aParams[] = $iId;
            
            Db::$FRDb->sqlExec($sQuery, $aParams);

            return TRUE;
        }
        
        return FALSE;
    }


    /*
    // Metody publiczne
    */
    
    
    // metoda pobiera filtry do listy (CMS)
    public function readFilter($p_sFilter = '')
    {
        $sFilter = trim((string)($p_sFilter));
        
        // oprogramowujemy filtr
        if ($aFilter = explode('|', urldecode(base64_decode($sFilter))))
        {
            $sSearch = ((isset($aFilter[0])) ? trim((string)($aFilter[0])) : '');
            
            $aResult = array(
                'search' => $sSearch
            );
            
            return ($aResult);
        }
        
        return NULL;
    }

    // metoda pobiera liste wg parametrow, parametry podajemy poza metoda, przed jej wywolaniem
    public function get()
    {
        return($this->_fetch());
    }
    
    public function read()
    {
        $sCacheKey = __METHOD__;
        if (!($aList = Cache::get($sCacheKey)))
        {
            $aList = $this->_fetch();
            Cache::add($sCacheKey, $aList, (24*3600));
        }

        if (is_array($aList))
        {
            return($aList);
        }
    }
    
    // metoda waliduje przeslane dane w formularzu
    public function validate($p_iId = 0, $p_fValue, $p_sTitle, $p_sCode, $p_sSymbol)
    {
        $iId = ((int)($p_iId)); // id stawki
        $fValue = ((real)($p_fValue)); // wartosc
        $sTitle = trim((string)($p_sTitle)); // nazwa
        $sCode = trim((string)($p_sCode)); // kod
        $sSymbol = trim((string)($p_sSymbol)); // symbol
        
        // nazwa byc musi
        if (!$sTitle)
        {
            Error::set('ErrorTitle', 'Wpisz nazwę.');
        }
        
        // nazwa byc musi
        if (!$sCode)
        {
            Error::set('ErrorCode', 'Wpisz kod.');
        }
        
        // nazwa byc musi
        if (!$sSymbol)
        {
            Error::set('ErrorSymbol', 'Wpisz symbol.');
        }
        
        // wartosc byc musi
        if ($fValue <= round(0, 2))
        {
            Error::set('ErrorValue', 'Wpisz cenę większą od zera.');
        }

        if (!Error::check())
        {
            return TRUE;
        }
        
        return FALSE;
    }
    
    // metoda zapisuje baner
    public function save($p_iId = 0, array $p_aData = NULL)
    {
        $iId = ((int)($p_iId));
        $aData = ((array)($p_aData));
        
        // przeliczenie waluty
        $aData['value'] = round(1/$aData['value'], 3);
        
        if ($iId > 0)
        {
            return ($this->_update($iId, $aData));
        }
        else
        {
            //return ($this->_create($aData));
        }
        
        return FALSE;
    }
    
    // metoda usuwa walute
    public function delete() {}
}
?>
