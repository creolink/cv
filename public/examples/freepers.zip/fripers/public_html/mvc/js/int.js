/**
 *
 * int.js - skrypty intro - wykorzystane w elemencie 'intro.php'
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 CreoLink, http://www.creolink.pl/
 *
 */

$(document).ready(
    function()
    {
        // przewijak banerow
        var iInterval;
        
        function setImg(p_iCursor)
        {
            if (typeof p_iCursor == 'undefined' || !p_iCursor) { p_iCursor = 1; }
            
            var iId, sId;
            var iStep = 1 * p_iCursor;
            
            var iMax = parseInt($('#int div.big div.bignav .ileft').attr('rel').replace('#', ''));
            
            $.each( $('#int div.big img.vis'), function() {
                iId = parseInt($(this).attr('id').replace('intro', ''));
                
                $(this).fadeOut(
                    'slow', 'linear',
                    function()
                    {
                        $(this).removeClass('vis');
                        
                        iId += iStep;
                        
                        if (iId > iMax) { iId = 1; }
                        if (iId < 1) { iId = iMax; }
                        if (!$('#intro' + iId).length) { iId = 1; }

                        //alert(iId);

                        $('#intro' + iId).fadeIn(
                            'fast', 'linear',
                            function()
                            {
                                $(this).addClass('vis');
                            }
                        );
                    }
                );
            });
        }
        
        iInterval = setInterval(function(){ setImg() }, 3000);
        
        $('#int div.big div.bignav .ileft').click(
            function ()
            {
                clearInterval(iInterval);
                
                setImg(-1);
            }
        );

        $('#int div.big div.bignav .iright').click(
            function ()
            {
                clearInterval(iInterval);
                
                setImg(1);
            }
        );

        // preloader
        $.each( $('#int div.big img'), function() {
            $('<img/>')[0].src = $(this).attr('src');
        });
    }
);
