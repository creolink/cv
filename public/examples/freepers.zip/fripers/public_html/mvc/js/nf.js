/**
 *
 * nf.js - skrypty formularza rejestracji w newsletterze - wykorzystane w elemencie 'nws.form'
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 CreoLink, http://www.creolink.pl/
 *
 */
$(document).ready(
    function()
    {
        function position()
        {
            $("#nwsform").position({
                my: "center",
                at: "center",
                of: window
            });
        }
        
        position();
        
        $("body").delegate("#nsend", "click", function(e) {
            e.preventDefault();
            var oFormData, sCT;
            if (fIE < 0 || fIE >= 10.0) // fIE static.js
            {
                oFormData = new FormData();
                var aParams = $('.nwsf form').serializeArray();
                jQuery.each(aParams, function(key, val) {
                    oFormData.append(val.name, val.value);
                });
                oFormData.append('nsave', 1);
                sCT = false;
            }
            else
            {
                oFormData = $('.nwsf form').serialize();
                oFormData = oFormData + '&nsave=1';
                sCT = 'application/x-www-form-urlencoded; charset=UTF-8';
            }
            
            $.ajax({
                url: './n-ajax/save/?t=' + Math.ceil(Math.random() * 999999),
                type: 'post',
                data: oFormData,
                cache: false,
                contentType: sCT,
                processData: false,
                beforeSend: function() {
                    $("#nwsform").html('');
                    $('<div id="ovbg"></div>').appendTo("body");
                },
                success: function(data) {
                    $('#nemail').removeClass('fe');
                    $("#nwsform").html(data); $("#nwsform").show();
                    position();
                }
            });
        });
        
        $("body").delegate("#nfmc, #ovbg", "click", function() {
            $('#nfmc').parent().hide();
            $('#nfmc').parent().html('');
            $('#ovbg').remove();
        });
    }
);
