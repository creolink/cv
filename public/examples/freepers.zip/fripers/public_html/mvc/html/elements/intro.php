<?php
/**
 *
 * intro - intro na stronie glownej
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
if (is_array($this->_aBnnSmall) && sizeof($this->_aBnnSmall) > 0
    || is_array($this->_aBnnBig) && sizeof($this->_aBnnBig) > 0
    )
{
?>
<div id="int" class="cnt cf">
    <?php
    if (is_array($this->_aBnnBig) && sizeof($this->_aBnnBig) > 0)
    {
    ?>
    <div class="big">
        <?php
            $iCounter = 0;
            foreach ($this->_aBnnBig as $aData)
            {
                $iCounter++;
        ?>
        <?php
                if ($aData['BnrUrl'] != '')
                {
        ?>
        <a href="<?php echo $aData['BnrUrl']; ?>"><img id="intro<?php echo $iCounter; ?>" src="<?php echo $aData['BnrSrc']; ?>" alt="<?php echo $aData['BnrTitle']; ?>"<?php if ($iCounter == 1) { ?> class="vis"<?php } ?>/></a>
        <?php
                }
                else
                {
        ?>
        <img id="intro<?php echo $iCounter; ?>" src="<?php echo $aData['BnrSrc']; ?>" alt="<?php echo $aData['BnrTitle']; ?>"<?php if ($iCounter == 1) { ?> class="vis"<?php } ?>/>
        <?php
                }
        ?>
        <?php
            }
        ?>
        <div class="bignav">
            <img class="ileft" rel="#<?php echo $iCounter; ?>" src="<?php echo Config::BASE_Images; ?>arr_left.png"/>
            <img class="iright" src="<?php echo Config::BASE_Images; ?>arr_right.png"/>
        </div>
    </div>
    <?php
    }
    ?>
    <?php
    if (is_array($this->_aBnnSmall) && sizeof($this->_aBnnSmall) > 0)
    {
    ?>
    <div class="sml">
        <?php
            foreach ($this->_aBnnSmall as $aData)
            {
        ?>
        <a href="<?php echo $aData['BnrUrl']; ?>"><img src="<?php echo $aData['BnrSrc']; ?>" alt="<?php echo $aData['BnrTitle']; ?>"/></a>
        <?php
            }
        ?>
    </div>
    <?php
    }
    ?>
</div>
<?php
}
?>
