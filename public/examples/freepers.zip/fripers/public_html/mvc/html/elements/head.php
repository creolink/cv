<?php
/**
 *
 * htmlheader - metatagi - czyli naglowek kazdego html-a
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title><?php echo $this->_sMetaTitle; ?></title>
    <meta name="description" content="<?php echo $this->_sMetaDescription; ?>"/>
    <meta name="keywords" content="<?php echo $this->_sMetaKeywords; ?>"/>
    <?php if ($this->_sMetaRobots != '') { ?><meta name="robots" content="<?php echo $this->_sMetaRobots; ?>"/><?php } ?>
    <meta name="author" content="<?php echo $this->_sMetaAuthor; ?>"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <link rel="dns-prefetch" href="https://www.google-analytics.com"/>
    <link rel="dns-prefetch" href="https://apis.google.com"/>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com"/>
    <link rel="dns-prefetch" href="https://accounts.google.com"/>
    <link rel="dns-prefetch" href="https://maps.gstatic.com"/>
    <link rel="dns-prefetch" href="https://facebook.com"/>
    <link rel="dns-prefetch" href="https://platform.twitter.com"/>
    <base href="<?php echo $this->_sMetaBase; ?>" />
    <link rel="SHORTCUT ICON" href="<?php echo Config::BASE_Images; ?>favicon.ico"/>
    <?php if ($this->_sMetaCanonical != '') { ?><link rel="canonical" href="<?php echo $this->_sMetaCanonical; ?>"/><?php } ?>
    <?php if ($this->_sMetaPrev != '') { ?><link rel="prev" href="<?php echo $this->_sMetaPrev; ?>"/><?php } ?>
    <?php if ($this->_sMetaNext != '') { ?><link rel="next" href="<?php echo $this->_sMetaNext; ?>"/><?php } ?>
    <?php echo $this->_sJSGoogleAnalytics; ?>
    <?php echo $this->_sJSIncludedModules; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $this->_sHeadCss; ?>" />
    <!--[if IE]><link rel="stylesheet" type="text/css" href="<?php echo $this->_sHeadCssIE; ?>"/><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" type="text/css" href="<?php echo $this->_sHeadCssIE7; ?>"/><![endif]-->
    <link rel="stylesheet" type="text/css" href="<?php echo $this->_sPrintCss; ?>" media="print" />
    <script type="text/javascript" src="/mjs/jq-jqui-css3m.js"></script>
    <?php
    /*
    // CND google-a
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
    */
    ?>
</head>
