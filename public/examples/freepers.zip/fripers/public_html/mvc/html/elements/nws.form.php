<?php
/**
 *
 * nws.form - formularz zapisania do nws (potwierdzenie zapisania)
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
if ($this->_bShow)
{
?>
<img id="nfmc" src="<?php echo Config::BASE_Images; ?>close.jpg" alt="<?php echo $this->_sTClose; ?>"/>
<?php
    if ($this->_bSaved)
    {
?>
<div id="nfmok">
    <h1><?php echo $this->_sTTitle; ?></h1>
    <p><?php echo $this->_sTInfo; ?></p>
</div>
<?php
    }
    else
    {
?>
<div id="nfm">
    <h1><?php echo $this->_sTTitle; ?></h1>
    <div class="errbox"><img src="<?php echo Config::BASE_Images; ?>/error.jpg" alt=""/><?php echo $this->_sError; ?></div>
</div>
<?php
    }
?>
<?php
}
else // pusta warstwa - w niej umiescimy formularz (to powyzej) zaladowany ajaxem
{
?>
<div id="nwsform"></div>
<?php
}
?>
