<?php
/**
 *
 * producer - lista produktow wg producenta - wykorzystane w producer.element
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
if (is_array($this->_aData) && sizeof($this->_aData) > 0)
{
?>
<?php echo $this->_oNavi; ?>
<div id="cat" class="cnt cf">
    <h1>
        <?php echo $this->_aData['PcrName']; ?> <span>(<?php echo$this->_sTProducts; ?>)</span>
    </h1>
    <?php echo $this->_oProdList; ?>
</div>
<?php
}
?>
