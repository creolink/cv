<?php
/**
 *
 * NwsFormElement - formularz rejestracji w newsletterze - obsluga elementu html/elements/nws.form.php
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class NwsFormElement extends ElementView
{
    /*
    // Deklaracje pol klasy
    */


    protected $_sElement = 'nws.form';        // nazwa elementu

    protected $_aCss = array(                 // lista arkuszy css wykorzystywanych w elemencie
        'nf'
        );

    protected $_aJs = array(                  // lista skryptow js wykorzystywanych w elemencie
        'nf'
        );

    protected $_bShow = FALSE;                // flaga pokazania formularza: 0 - nie, 1 - tak
    protected $_bSaved = FALSE;               // flaga zapisania: 0 - zapisany poprawnie, 1 - bledy
    

    /*
    // Konstruktor i destruktor
    */


    public function __construct($p_bShow = FALSE, $p_bSaved = FALSE)
    {
        $this->_bShow = ((bool)($p_bShow));
        $this->_bSaved = ((bool)($p_bSaved));
        
        $this->_sTClose = Dictionary::getText('close');
        $this->_sTTitle = Dictionary::getText('nws.form.title');
        $this->_sTInfo = Dictionary::getText('nws.form.thanks');
        
        if ($this->_bShow)
        {
            if (Form::readErrors('ErrorNws')) { $this->_sError = Form::$sErrorStr; }
            
            Form::clearErrors('ErrorNws');
        }
        
        return($this);
    }


    /*
    // Metody prywatne, protected
    */


    /*
    // Metody publiczne
    */
}
?>
