<?php
/**
 *
 * ProducerElement - lista produktow wg producenta - obsluga elementu html/elements/producer.php
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class ProducerElement extends ElementView
{
    /*
    // Deklaracje pol klasy
    */


    protected $_sElement = 'producer';        // nazwa elementu

    protected $_aCss = array(                 // lista arkuszy css wykorzystywanych w elemencie
        'cat'
        );

    protected $_aJs = array(                  // lista skryptow js wykorzystywanych w elemencie
        );
    
    protected $_aData = array();              // dane producenta
    
    protected $_oNavi = NULL;                 // obiekt nawigacji / breadcrumbs
    protected $_oProdList = NULL;             // obiekt listy produktow
    
    protected $_sTProducts = '';              // tekst w naglowku (... produktow w sklepie)


    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {
        $oProducers = new ProducersModel();
        
        // pobieramy dane kategorii
        if ($this->_aData = $oProducers->read())
        {
            // element nawigacji / breadcrumbs
            $aNavi[] = array($this->_aData['PcrName'], $this->_aData['PcrSiteLink']);
            $this->_oNavi = new NaviElement($aNavi); $this->_oNavi->setCssJs();
            
            // lista produktow
            $this->_oProdList = new ProductsElement(); $this->_oProdList->setCssJs();
            $this->_sTProducts = Dictionary::getText('plist.total', array($this->_oProdList->iTotal));
        }

        return($this);
    }


    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


}
?>
