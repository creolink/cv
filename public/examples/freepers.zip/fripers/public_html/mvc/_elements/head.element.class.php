<?php
/**
 *
 * HeadElement - obsluga elementu html/elements/head.php (naglowki htmlowe <head></head>, metatagi)
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class HeadElement extends ElementView
{
    /*
    // Deklaracje pol klasy
    */


    protected $_sElement = 'head';                            // nazwa elementu

    protected $_aCss = array(                                 // lista arkuszy css wykorzystywanych w elemencie
        );
    
    protected $_aJs = array(                                  // lista skryptow js wykorzystywanych w elemencie
        );

    protected $_sMetaTitle = '';                              // wartosc metatagu title
    protected $_sMetaDescription = '';                        // wartosc metatagu description
    protected $_sMetaKeywords = '';                           // wartosc metatagu keywords
    protected $_sMetaAuthor = '';                             // wartosc metatagu autor
    protected $_sMetaStudio = '';                             // wartosc metatagu studio
    protected $_sMetaEmail = '';                              // wartosc metatagu email
    protected $_sMetaBase = '';                               // wartosc tagu base
    protected $_sJSIncludedModules = '';                      // dodane skrypty javascript wykorzystawane w widoku
    protected $_sJSGoogleAnalytics = '';                      // dodane skrypty google analytics
    protected $_sHeadCss = '';                                // dynamicznie tworzone css-y do zaladowania
    protected $_sHeadCssIE = '';                              // cssy dla ie, dodawane warunkowo w html tylko dla przegladarki ie
    protected $_sMetaRobots = 'index,follow,archive';         // wartosc metatagu robots
    protected $_sMetaCanonical = '';                          // kanoniczny adres URL
    protected $_sMetaPrev = '';                               // poprzednia strona
    protected $_sMetaNext = '';                               // nastepna strona
    

    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {
        $oMeta = new MetaModel();

        $aMetaData = $oMeta->get();

        $this->_sMetaTitle = $aMetaData['Title'];
        $this->_sMetaDescription = $aMetaData['Description'];
        $this->_sMetaKeywords = $aMetaData['Keywords'];
        $this->_sMetaAuthor = $aMetaData['Author'];
        $this->_sMetaStudio = $aMetaData['Studio'];
        $this->_sMetaEmail = $aMetaData['Email'];
        $this->_sMetaBase = $aMetaData['Base'];
        
        $this->_sMetaRobots = ((!isset($aMetaData['Robots'])) ? $this->_sMetaRobots : $aMetaData['Robots']);
        $this->_sMetaCanonical = (isset($aMetaData['Canonical']) ? $aMetaData['Canonical'] : '');
        
        $this->_sMetaPrev = ((isset($aMetaData['Prev']) ? $aMetaData['Prev'] : ''));
        $this->_sMetaNext = ((isset($aMetaData['Next']) ? $aMetaData['Next'] : ''));
        
        $this->_sHeadCssIE = Config::BASE_CSS.'ie.'.Config::CACHE_MinCss;
        $this->_sHeadCssIE7 = Config::BASE_CSS.'ie7.'.Config::CACHE_MinCss;

        // dynamiczne tworzone css i js
        $this->_sHeadCss = &HtmlView::$sCss;
        $this->_aCss = &HtmlView::$aCss;
        $this->_sPrintCss = Config::BASE_CSS.'print.css';
        
        $this->_sJSIncludedModules = '';

        // w cms nie ladujemy GA
        if (isset(Router::$aTemplateData['in_map']) && Router::$aTemplateData['in_map'])
        {
            $this->_sJSGoogleAnalytics = new AnalyticsElement();
        }
        
        return($this);
    }


    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


}
?>
