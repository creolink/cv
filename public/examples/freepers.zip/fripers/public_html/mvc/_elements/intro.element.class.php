<?php
/**
 *
 * IntroElement - intro / banery na stronie glownej - obsluga elementu html/elements/intro.php
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class IntroElement extends ElementView
{
    /*
    // Deklaracje pol klasy
    */


    protected $_sElement = 'intro';            // nazwa elementu

    protected $_aCss = array(                  // lista arkuszy css wykorzystywanych w elemencie
        'int'
        );

    protected $_aJs = array(                   // lista skryptow js wykorzystywanych w elemencie
        'int'
        );

    protected $_aBnnSmall = array();           // lista banerow malych
    protected $_aBnnBig = array();             // lista banerow duzych
    

    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {
        $oBanners = new BannersModel();
        
        $this->_aBnnSmall = $oBanners->getPlace('intro-small', Config::$iLangId, 3);
        $this->_aBnnBig = $oBanners->getPlace('intro-big', Config::$iLangId, 5);
        
        return($this);
    }


    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


}
?>
