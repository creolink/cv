<?php
/**
 *
 * XmlView - klasa tworzaca widok pliku xml
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class XmlView
{
    /*
    // Deklaracje pol klasy
    */



    /*
    // Konstruktor i destruktor
    */




    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


    public function display(array $p_aFileData = NULL)
    {
        $aFileData = ((array)($p_aFileData));
        
        header(Lib::getHeaders(200));

        $aFileData['Type'] = 'xml';
        $aFileData['Headers']['Content-Type'] = Lib::getMimeContentType('xml');
        
        if (is_array($aFileData['Headers']) && sizeof($aFileData['Headers']) > 0)
        {
            foreach ($aFileData['Headers'] as $sHeader => $sHeaderValue)
            {
                header($sHeader.':'.$sHeaderValue);
            }
        }

        echo $aFileData['Stream']; die();
    }
}
?>
