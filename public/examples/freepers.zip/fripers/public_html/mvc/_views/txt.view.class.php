<?php
/**
 *
 * TxtView - klasa tworzaca widok pliku tekstowego
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class TxtView
{
    /*
    // Deklaracje pol klasy
    */



    /*
    // Konstruktor i destruktor
    */




    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


    public function display($p_aFileData)
    {
        if (headers_sent()) { die('BLAD HEADERS SENT'); }
        
        header(Lib::getHeaders(200));

        if (isset($p_aFileData['Headers']) && is_array($p_aFileData['Headers']) && sizeof($p_aFileData['Headers']) > 0)
        {
            foreach ($p_aFileData['Headers'] as $sHeader => $sHeaderValue)
            {
                header($sHeader.':'.$sHeaderValue);
            }
        }

        if (isset($p_aFileData['Stream']))
        {
            echo $p_aFileData['Stream']; die();
        }
    }
}
?>
