<?php
/**
 *
 * SiteNwsController - kontroler newslettera
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class SiteNwsController extends Controller
{
    /*
    // Deklaracje pol klasy
    */

    
    const Css = '';                // style dla widoku
    const Js = '';                 // js dla widoku


    /*
    // Konstruktor i destruktor
    */





    /*
    // Metody protected
    */


    protected function _display()
    {
        $oMeta = new MetaModel(); $oMeta->set(); // ustawiamy metatagi
        
        $this->_oView->display(Router::$aTemplateData['template_name'], self::Css, self::Js);
    }
    
    // weryfikacja adresu e-mail (z linka wyslanego w mailu MailVerifyElement)
    protected function _verify()
    {
        if (
            isset(Router::$aAddress[1]) && isset(Router::$aAddress[2])
            && strlen(Router::$aAddress[1]) == 32 && strlen(Router::$aAddress[2]) > 0
            )
        {
            $oNwsEmails = new NwsEmailsModel();
            
            // pobieramy adres e-mail, ktory ma byc zweryfikowany
            $oNwsEmails->sEmailMD5 = Router::$aAddress[1];
            $oNwsEmails->sCode = Router::$aAddress[2];
            if ($aData = $oNwsEmails->get())
            {
                $oNwsEmails->verify($aData['NwsEmail']);
            }
        }
        
        $this->_display();
    }
    
    protected function _ajax()
    {
        $oAjax = new AjaxModel();
        $oNwsEmails = new NwsEmailsModel();

        $sStream = ''; $aItems = NULL; $sMime = 'html';
        $sItemLabel = ''; $sItemValue = ''; $sItemKey = '';

        switch($oAjax->read()->sAction)
        {
            case 'save': // zapisanie opinii
                if (!isset(Form::$aFormData['nsave']) || !Form::$aFormData['nsave'])
                {
                    $sStream = new NwsFormElement(TRUE);
                }
                else
                {
                    $aFData = &Form::$aFormData;
                    
                    // walidacja wyslanego formularza
                    if ($oNwsEmails->validate($aFData['nemail']))
                    {
                        $aData = array();
                        
                        $aData['email'] = $aFData['nemail'];
                        $aData['customers_id'] = ((Customer::$bLogged && Customer::$iId > 0) ? Customer::$iId : 0); // ustawiamy klienta
                        
                        // zapisujemy opinie
                        if ($oNwsEmails->save($aData))
                        {
                            $sStream = new NwsFormElement(TRUE, TRUE);
                        }
                        else
                        {
                            $sStream = 'Nws ERROR: Nie udalo sie zapisac adresu'; die();
                        }
                    }
                    else
                    {
                        $aFormErrors = array();
                        $aFormErrors['f_email'] = Error::get('ErrorEmail');
                        
                        Form::saveErrors('ErrorNws', $aFormErrors);
                        
                        $sStream = new NwsFormElement(TRUE);
                    }
                }
                break;
                
            default:
                break;
        }

        // wyswietlamy dane
        $this->_oView->display($oAjax->get($sStream, $aItems, $sMime, $sItemLabel, $sItemValue, $sItemKey));
    }
    

    /*
    // Metody prywatne
    */


    


    /*
    // Metody publiczne
    */


}
?>
