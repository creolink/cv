<?php
/**
 *
 * SiteProductController - kontroler karty towaru
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class SiteProductController extends Controller
{
    /*
    // Deklaracje pol klasy
    */

    
    const Css = '';                // style dla widoku
    const Js = '';                 // js dla widoku


    /*
    // Konstruktor i destruktor
    */





    /*
    // Metody protected
    */


    protected function _display()
    {
        if (!$this->_set())
        {
            Router::redirect(Router::createFull()); // nie ma takiego produktu - przenosimy na strone glowna
        }
        
        $this->_oView->display(Router::$aTemplateData['template_name'], self::Css, self::Js);
    }
    
    protected function _set()
    {
        $oProduct = new ProductModel();
        $oMeta = new MetaModel();
        
        $sLink = ((isset(Router::$aAddress[1])) ? Router::$aAddress[1] : '');
        
        if (strlen($sLink) > 0 && ($oProduct->iLangId = Config::$iLangId) && ($oProduct->sLink = $sLink) && ($oProduct->read()))
        {
            $aData = &$oProduct::$aData;
            
            // ustawiamy metatagi
            $oMeta->set(
                (($aData['PrMTitle'] != '') ? $aData['PrMTitle'] : $aData['PrNameFull']),
                (($aData['PrMDescr'] != '') ? $aData['PrMDescr'] : $aData['PrDscr']),
                Router::createFull($aData['PrSiteLink']),
                NULL,
                NULL,
                'index,follow,noarchive'
            );
            
            $oProduct->setDAddr($aData['PrId']);

            return TRUE;
        }
        else if (strlen($sLink) > 0)
        {
            // przechodzimy do wyszukiwarki
            Router::redirect(Router::link(9, preg_replace('~[-]~', ' ', Lib::clearUrl($sLink)))); die();
        }
    }
    
    protected function _ajax()
    {
        $oAjax = new AjaxModel();
        $oProduct = new ProductModel();

        $sStream = ''; $aItems = NULL; $sMime = 'html';
        $sItemLabel = ''; $sItemValue = ''; $sItemKey = '';

        switch($oAjax->read()->sAction)
        {
            case 'rate': // glosowanie na produkt
                $iPrId = Lib::clearUrl($_GET['p']); // id produktu
                $iRate = Lib::clearUrl($_GET['r']); // ocena
                
                if ($iPrId > 0 && $iRate > 0)
                {
                    $oProduct->rate($iPrId, 1, $iRate);
                }
                break;
            
            default:
                break;
        }

        // wyswietlamy dane
        $this->_oView->display($oAjax->get($sStream, $aItems, $sMime, $sItemLabel, $sItemValue, $sItemKey));
    }
    

    /*
    // Metody prywatne
    */


    


    /*
    // Metody publiczne
    */


}
?>
