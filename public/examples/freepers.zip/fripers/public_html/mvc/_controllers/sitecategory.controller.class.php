<?php
/**
 *
 * SiteCategoryController - sterownik widoku kategorii glownej / podkategorii
 *
 * @package CreoCart, powered by CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class SiteCategoryController extends Controller
{
    /*
    // Deklaracje pol klasy
    */

    
    const Css = '';                    // style dla widoku
    const Js = '';                     // js dla widoku


    /*
    // Konstruktor i destruktor
    */





    /*
    // Metody protected
    */

    
    // kontroler wyswietlenia szablonu
    protected function _display()
    {
        if (!$this->_set())
        {
            Router::redirect(Router::createFull()); // nie ma takiej kategorii - przenosimy na strone glowna
        }
        
        $this->_oView->display(Router::$aTemplateData['template_name'], self::Css, self::Js);
    }
    
    protected function _set()
    {
        // pobieramy dane kategorii
        $oCategories = new CategoriesModel();
        
        // link np: /c/filtr-pol-58mm/a12-123-432.a45-234-867.p545.c-100-600.o-ab12/
        // Router::$aAddress[X], dla X:
        //  0 - szablon, widok kategorii 'c'
        //  1 - link kategorii
        //  2 - filtry i sortowanie oraz stronicowanie, rozdzielone znakiem '.'
        //    a12-123-432 : parametr id 12 z opcjami id 123 i 432
        //    p545 : producent z id 123
        //    c-100-600 : cena od 100 do 600
        //    o- : stronicowanie i sortowanie
        
        $sCatLink = ((isset(Router::$aAddress[1])) ? Router::$aAddress[1] : '');
        
        if (strlen($sCatLink) > 0 && ($aData = $oCategories->read(0, $sCatLink, Config::$iLangId, TRUE, TRUE)))
        {
            $oMeta = new MetaModel();
            
            // lista produktow jest dla kategorii poziomu 2 i kolejnych
            if (!$aData['CatShowSub'])
            {
                $oProducts = new ProductsModel();
                $oFilters = new FiltersModel();
                
                // obsluga post-a z filtrami
                $bReload = FALSE; $aPF = array();
                if (isset(Form::$aFormData['filrem']) && Form::$aFormData['filrem']) // usuwamy filtry
                {
                    Router::redirect(Router::createFull($aData['CatSiteLink'])); die();
                }
                else if (isset(Form::$aFormData['filsave']) && Form::$aFormData['filsave']) // wybrane filtry
                {
                    $aPF = Form::$aFormData['f'];
                    $bReload = TRUE;
                }
                
                // stronicowanie i filtrowanie oraz obsluga post-a z filtrami - wybrane filtry
                $aUrlMap = $oProducts->readUrl(
                    ((isset(Router::$aAddress[2])) ? Router::$aAddress[2] : ''),
                    ((isset($aPF['po'])) ? $aPF['po'] : NULL),
                    ((isset($aPF['prc'])) ? $aPF['prc'] : NULL),
                    ((isset($aPF['prd'])) ? $aPF['prd'] : NULL),
                    ((isset($aPF['prd']) && !$aPF['prd']) ? TRUE : FALSE)
                );
                
                // dane do listy produktow
                $oProducts->iLangId = Config::$iLangId;
                $oProducts->iPage = $aUrlMap[5];
                $oProducts->iLimit = 15;
                $oProducts->sSortColumn = $aUrlMap[4];
                $oProducts->sSortOrder = $aUrlMap[3];
                $oProducts->iCatId = $aData['CatId'];
                $oProducts->aSFilters = $aUrlMap[0];
                $oProducts->aPrices = $aUrlMap[2];
                $oProducts->iPcrFilter = $aUrlMap[1];
                $oProducts->bGetFull = TRUE;
                $oProducts->bSetSort = TRUE;
                $oProducts->sUrl = $aData['CatSiteLink'];
                $oProducts->sTitle = $aData['CatName'];
                
                // obsluga post-a z filtrami - wybrane filtry, przekierowanie na prawidlowy adres
                if ($bReload)
                {
                    Router::redirect(Router::createFull($aData['CatSiteLink'].$oProducts->setUrl())); die();
                }
                
                // pobieramy liste produktow
                if (!$oProducts->read(TRUE) && (sizeof($oProducts->aSFilters) > 0 || sizeof($oProducts->aPrices) > 0 || $oProducts->iPcrFilter > 0))
                {
                    // jesli sa wybrane filtry i nie znaleziono produktow to filtrujemy z 'lub'
                    $oProducts->bFilterOr = TRUE;
                    $oProducts->bRArr = TRUE;
                    $oProducts->read(TRUE);
                }
                
                // jesli nie ma produktow i strona > 1 to wracamy na 1 strone
                if ($oProducts->iPage > 0 && (!isset(ProductsModel::$aData) || $oProducts->iPage > ProductsModel::$aData['maxpages']))
                {
                    $oProducts->iPage = 0;
                    Router::redirect(Router::createFull($aData['CatSiteLink'].$oProducts->setUrl())); die();
                }
                
                // pobieramy filtry
                $sFTitle = '';
                if (isset(ProductsModel::$aData))
                {
                    $oFilters->iLangId = Config::$iLangId;
                    $oFilters->aProds = ProductsModel::$aData['ids'];
                    $oFilters->aPrices = ProductsModel::$aData['prices'];
                    $oFilters->aProducer = ProductsModel::$aData['producer'];
                    $oFilters->aFilters = ProductsModel::$aData['filters'];
                    $oFilters->aSort = ProductsModel::$aData['sort'];
                    $oFilters->sUrl = $aData['CatSiteLink'];
                    $oFilters->read(TRUE);
                    
                    $aFTitle = array();

                    // dopisujemy wybrane filtry do meta title
                    if (is_array(ProductsModel::$aData['filters'][3]) && sizeof(ProductsModel::$aData['filters'][3]) > 0)
                    {
                        foreach (ProductsModel::$aData['filters'][3] as &$sFilter)
                        {
                            if (isset(FiltersModel::$aData[1][$sFilter]['FOName']) && FiltersModel::$aData[1][$sFilter]['FOName'])
                            {
                                $aFTitle[] = FiltersModel::$aData[1][$sFilter]['FOName'];
                            }
                        }
                    }
                    
                    // dopisujemy ceny do meta title
                    if (ProductsModel::$aData['prices'][0] > 0 || ProductsModel::$aData['prices'][1] > 0)
                    {
                        $aFTitle[] .= Dictionary::getText('plist.filter.price').' '
                            .trim(
                                ((ProductsModel::$aData['prices'][0] > 0) ? Dictionary::getText('plist.filter.price.from').' '.ProductsModel::$aData['prices'][0].' ' : '')
                                .((ProductsModel::$aData['prices'][1] > 0) ? Dictionary::getText('plist.filter.price.to').' '.ProductsModel::$aData['prices'][1] : '')
                            );
                    }
                    
                    // dopisujemy producenta do meta title
                    if (isset(ProductsModel::$aData['producer']) && ProductsModel::$aData['producer'][0] > 0)
                    {
                        $oProducers = new ProducersModel();
                        $oProducers->iId = ProductsModel::$aData['producer'][0];
                        $aProducer = $oProducers->get();
                        
                        $aFTitle[] = $aProducer['PcrName'];
                    }
                    
                    $sFTitle = implode(', ', $aFTitle);
                }
            }
            
            // ustawiamy metatagi
            $sTitle = ((isset($sFTitle) && $sFTitle) ? $sFTitle.', ' : '')
                .(($aData['CatMTitle'] != '') ? $aData['CatMTitle'] : (($aData['CatHeadingTitle'] != '') ? $aData['CatHeadingTitle'] : (($aData['CatName'] != '') ? $aData['CatName'] : Router::$aTemplateData['meta_title'])))
                .((!$aData['CatShowSub'] && $oProducts->iPage > 0) ? ', '.Dictionary::getText('meta.page').' '.($oProducts->iPage + 1) : '')
                .((isset(ProductsModel::$aData['sort']['now']['hname'])) ? ', '.ProductsModel::$aData['sort']['now']['hname'] : '');
            
            $sDescr = (($aData['CatMDescr'] != '') ? $aData['CatMDescr'] : (($aData['CatName'] != '') ? $aData['CatName'] : ''));

            $oMeta->set(
                $sTitle,
                $sDescr,
                Router::$sAddress, // Router::createFull($aData['CatSiteLink'].((!$aData['CatShowSub']) ? $oProducts->setUrl() : ''))
                ((!$aData['CatShowSub'] && isset(ProductsModel::$aData['sort']['prev']) && $oProducts->iPage > 0) ? Router::createFull(ProductsModel::$aData['sort']['prev']) : ''),
                ((!$aData['CatShowSub'] && isset(ProductsModel::$aData['sort']['next']) && $oProducts->iPage < ProductsModel::$aData['maxpages']) ? Router::createFull(ProductsModel::$aData['sort']['next']) : ''),
                ((!$aData['CatShowSub'] && $oProducts->iPage > 0) ? 'index,follow,noarchive' : '')
            );
            
            // linki dla pozostalych jezykow
            $oCategories->setDAddr($aData['CatId']);
            
            return TRUE;
        }
        else if (strlen($sCatLink) > 0)
        {
            // przechodzimy do wyszukiwarki
            Router::redirect(Router::link(9, preg_replace('~[-]~', ' ', Lib::clearUrl($sCatLink)))); die();
        }
    }
    

    /*
    // Metody prywatne
    */


    


    /*
    // Metody publiczne
    */

    
}
?>
