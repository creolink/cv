<?php
/**
 *
 * Konfiguracja poziomu DEBUGu
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
require_once (dirname(__FILE__)."/ConfigDb.php");

abstract class ConfigDebug extends ConfigDb //ConfigPaths
{
    // DEBUG_Program == FALSE - wylaczony calkowicie
    // DEBUG_Program == TRUE - wlaczony
    // DEBUG_Database == FALSE - wylaczony calkowicie

    const DEBUG_Database        = TRUE;           // wlaczony/wylaczony DEBUG zapytan baz: TRUE / FALSE
    const DEBUG_Program            = TRUE;        // wlaczony/wylaczony DEBUG programu: TRUE / FALSE
    const SQL_NO_CACHE            = TRUE;         // wylaczone cache-owanie zapytan sql
    const DEBUG_Ajax                = FALSE;      // wlaczenie debugu w ajax-sie

    public static $bShowDebug    = TRUE;          // czy pokazywac debug (zmienna wykorzystana w widokach, w ktorych nie moze byc debugu, np: Minify, wyniki AJAX)
}
?>
