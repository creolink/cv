<?php
/**
 *
 * Konfiguracja programu
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
require_once (dirname(__FILE__)."/ConfigDebug.php");

abstract class ConfigRuntime extends ConfigDebug
{
    // adresy
    const BASE_Addresses                    = 'fripers.pl';                                     // adres systemu, multiportal - obslugiwane adresy przez program, rozdzielone znakiem '|' - rozpoznanie po wpisanym adresie (dokladnie domenie, np creolink.pl|creocart.pl)
    const BASE_Codes                        = 'fripers';                                        // kody portali sitemap.url_portal, rozdzielone znakiem '|' - odpowiednio dla stalej 'BASE_Addresses'
    const BASE_WWW                          = FALSE;                                            // czy wymusic w adresie 'www.': TRUE / FALSE

    // sciezki html-owe
    const BASE_Images                       = '/i/';                                            // katalog obrazkow layoutu
    const BASE_JS                           = '/mjs/';                                          // katalog skryptow js
    const BASE_CSS                          = '/mcss/';                                         // katalog styli css
    const BASE_CKEditor                     = '/ckeditor/';                                     // adres ckeditora

    // parametry http / ssl
    const Protocol                          = 'http://';                                        // domyslny protokol
    const SSL_Protocol                      = 'https://';                                       // protokol ssl
    const SSL_ProtocolPort                  = '';                                               // port ssl, $_SERVER['SERVER_PORT']

    // sesje
    const SessionUseTransSid                = FALSE;                                            // czy zapisywac id sesji w zmiennej php sid: FALSE / TRUE
    const SessionUseCookies                 = TRUE;                                             // czy sesja ma uzywac W OGOLE cookies: FALSE / TRUE
    const SessionUseOnlyCookies             = TRUE;                                             // czy sesja ma uzywac TYLKO cookies: FALSE / TRUE
    const SessionHashFunction               = 1;                                                // szyfrowanie id sesji: 0 - MD5, 1 - SHA1
    const SessionName                       = 'FRIPERS';                                        // nazwa sesji
    const SessionLifeTime                   = 172800;                                           // czas zycia sesji w sekundach (48h = 172800s)
    const SessionSaveHandler                = 'files';                                          // sposob uzycia sesji
    const SessionCookieDomains              = '.fripers.pl';                                    // domeny dla ciastek i sesji, rozdzielone znakiem '|' wg kodow adresow BASE_Codes
    const SessionCookiePath                 = '/';                                              // sciezka dla ciastek
    const SessionCacheLimiter               = 'nocache';                                        // ustawienia cache-owania sesji
    const DefaultLogoutTime                 = 43200;                                            // utrzymanie w sesji zalogowania klienta w sekundach (30 minut = 1800s)
    
    // ciastka
    const CookieUsrLogin                    = 'xxxxxxx';                                        // nazwa ciastka logowania - login
    const CookieUsrPass                     = 'xxxxxxx';                                        // nazwa ciastka logowania - haslo
    
    // bledy
    const ErrorReporting                    = E_ALL;                                            // E_STRICT, E_ALL ^ E_NOTICE ^ E_DEPRECATED
    const DisplayErrors                     = TRUE;                                             // TRUE / FALSE
    
    // kodowanie i mime
    const DefaultMimetype                   = 'text/html';                                      // domyslny typ mime
    const DefaultCharset                    = 'UTF-8';                                          // domyslne kodowanie
    const MagicQuotesGpc                    = 'off';                                            // magicquotes
    const AllowCallTimePassReference        = 'off';                                            // allowcalltimepassbyreference
    const Timezone                          = 'Europe/Warsaw';                                  // 'UTC', 'Europe/Warsaw'
    const HtmlCharset                       = 'utf-8';
    const Locale                            = 'pl_PL.utf8';                                     // do setlocale
    
    // pelna sciezka programu
    const RealPath                          = '/var/www/fripers2/';                             // pelna sciezka do projektu
    const FOLDER_Site                       = 'public_html/';                                   // sciezka do programu
    
    // konfiguracja programu - katalogi poza www
    const FOLDER_Tmp                        = 'tmp/';                                           // tymczasowe pliki zapisywane w trakcie pracy programu, niedostepne z poziomu www - pelna sciezka
    const FOLDER_Logs                       = 'logs/';                                          // folder logow - pelna sciezka RealPath.Config::FOLDER_Tmp
    
    // konfiguracja programu - katalogi z plikami (np dokumentow)
    const FOLDER_FilesPImages               = 'files/products/images/';                         // obrazki produktow
    
    // konfiguracja programu - silnik
    const FOLDER_Engine                     = 'engine/';                                        // katalog z silnikiem
    const FOLDER_EngineScripts              = 'engine/scripts/';                                // katalog z bibliotekami SP
    const FOLDER_EngineLibs                 = 'engine/libs/';                                   // katalog z bibliotekami klas OOP
    const FOLDER_EngineMVC                  = 'mvc/';                                           // katalog klass MVC
    const FOLDER_EngineViews                = 'mvc/_views/';                                    // katalog z klasami widokow
    const FOLDER_EngineModels               = 'mvc/_models/';                                   // katalog z klasami modeli
    const FOLDER_EngineControllers          = 'mvc/_controllers/';                              // katalog z klasami sterownikow
    const FOLDER_EngineElements             = 'mvc/_elements/';                                 // katalog z klasami elementow
    const FOLDER_EngineHTML                 = 'mvc/html/';                                      // katalog z zawartoscia html
    const FOLDER_EngineHTMLElements         = 'mvc/html/elements/';                             // katalog z szablonami elementów (klockami)
    const FOLDER_EngineHTMLTemplates        = 'mvc/html/templates/';                            // katalog z szablonami widoków
    const FOLDER_EngineCSS                  = 'mvc/css/';                                       // katalog z szablonami elementów (klockami)
    const FOLDER_EngineJS                   = 'mvc/js/';                                        // katalog z szablonami widoków

    // konfiguracja statystyk
    const STAT_Create                       = TRUE;                                             // czy zapisywac staty
    const STAT_Path                         = 'stat/';                                          // folder zapisu statystyk

    // adresy ip lub nazwy domen, z ktorych nie zapisujemy statow, rozdzielone przecinkiem (np adresy google)
    const STAT_NoStatHosts                  = '';

    // konfiguracja dla narzedzi Google
    const GOOGLE_AnalyticsCodes             = 'UA-xxxx-y';                                      // kody google analytics dla portali, rozdzielone znakiem '|' wg kodow adresow BASE_Codes
    const GOOGLE_MapCodes                   = '';                                               // kody map google dla portali, rozdzielone znakiem '|' wg kodow adresow BASE_Codess

    // cache
    const CACHE_Enabled                     = TRUE;                                             // czy ma byc wykorzystywany cache (np APC, MEMCACHE, etc)
    const CACHE_Tmp                         = '../tmp/cache/';                                  // katalog zapisanych plikow cache
    const CACHE_TmpMinCss                   = '../tmp/cache/css/';                              // katalog zapisanych plikow cache min css (dla light-a musza byc w katalogu glownym ze wzgledu na konfiguracje serwera "^(.*/)*(css|js)/(.+?\..*(css|js))$" => "index.php?path=$2/$3" )
    const CACHE_TmpMinJs                    = '../tmp/cache/js/';                               // katalog zapisanych plikow cache min js (dla light-a musza byc w katalogu glownym ze wzgledu na konfiguracje serwera "^(.*/)*(css|js)/(.+?\..*(css|js))$" => "index.php?path=$2/$3" )
    const CACHE_Engine                      = 'APC';                                            // silnik cacheowania APC, MEMCACHED, INTERNAL - wewnetrzny
    const CACHE_SaveMinified                = TRUE;                                             // czy zapisywac zminimalizowane css i js
    const CACHE_MinCss                      = 'css';                                            // rozszerzenie dla zminimalizowanych plikow css (uwaga, dotyczy rowniez konfiguracji serwera)
    const CACHE_MinJs                       = 'js';                                             // rozszerzenie dla zminimalizowanych plikow js (uwaga, dotyczy rowniez konfiguracji serwera)
    
    // CAPTCHA
    const CAPTCHA_ImageBg                   = './i/captcha_bg.jpg';                             // tlo obrazka : './i/captcha_bg.jpg'
    const CAPTCHA_ImageNoise                = './i/captcha_noise.png';                          // obrazek 'zaciemniajacy' literki : './i/captcha_noise.png'
    const CAPTCHA_TextFontPath              = './../private/files/fonts/';                      // sciezka do fontow :  './../private/files/fonts/'
    
    // ePlatnosci (PayU, PayPal)
    const PayU_Address                      = 'https://secure.payu.com/paygw/';                 // adres PayU (operacje platnicze), adresy https://secure.payu.com/paygw/ lub https://www.platnosci.pl/paygw/
    const PayU_Encoding                     = 'UTF/';                                           // kodowanie
    const PayU_NewPayment                   = 'NewPayment';                                     // metoda dla nowej platnosci
    const PayU_PaymentGet                   = 'Payment/get/xml';                                // metoda pobierajace dane platnosci
    const PayU_PosId                        = '111111';                                         // id punktu platnosci (konfiguracja w https://www.platnosci.pl/paygw/adm/index.jsp
    const PayU_PosAuthKey                   = '1234567';                                        // kod auth punktu platnosci (konfiguracja w https://www.platnosci.pl/paygw/adm/index.jsp
    const PayU_PosKey1                      = '1232132131231232132323232132313';                // kod 1, Klucz (MD5) z https://www.platnosci.pl/paygw/adm/index.jsp
    
    const PayPal_Address                    = 'https://www.sandbox.paypal.com/cgi-bin/webscr';  // adres PayPal (operacje platnicze): www.sandbox.paypal.com - srodowisko testowe
    const PayPal_Currency                   = 'PLN';                                            // waluta w ktorej placi klient
    const PayPal_Business                   = 'xxxx@xxxxxxxx.pl';                               // adres email firmy na ktory klient robi wplate (test: jakub.luczynski@creolink.pl)
    const PayPal_Socket                     = 'ssl://www.sandbox.paypal.com';                   // adres polaczenia socket-em do weryfikacji platnosci: www.sandbox.paypal.com - srodowisko testowe
    
    // FACEBOOK
    const FBookAppId                        = '';                                               // klucz api dla facebooka
    const FBookSecret                       = '';                                               // haslo do api - pobrac z https://developers.facebook.com/apps/__FBookAppId__/dashboard/
    
    // CZY TEST
    const TEST                              = FALSE;                                            // czy strona jest testowa i czy ma najpierw pojawiac sie logowanie
}
?>
