<?php
/**
 *
 * Silnik aplikacji
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class Engine
{
    /*
    // Deklaracje pol klasy
    */
    

    private $_iMaxTime = 0.5;                // maksymalny czas wykonywania skryptu - ostrzezenie wysylane mailem
    private $_iMaxRAM = 20971520;            // maksymalne zuzycie RAM-u dla skryptu (w bajtach) - ostrzezenie wysylane mailem
    
    private static $_aLoadedClasses;         // tablica-lista zaladowanych klas
    private static $_aLoadedElements;        // tablisa-lista zaladowanych elementow
    
    public static $aDebugData = array();     // tablica z danymi do debugu, dodawanymi recznie w programie (np w modelach)
    
    public static $aTimer = array();         // tablica z czasami generacji poszczegolnych elementow programu
    
    
    /*
    // Konstruktor i destruktor
    */
    
    
    public function __construct($p_sTarget = 'HTML')
    {
        $sTarget = trim((string)($p_sTarget));
        
        $this->_loadConfig();                                  // zaladowanie konfiguracji
        $this->_loadCore();                                    // wgranie wymaganych klas
        
        Timer::start();                                        // uruchomienie czasomierza
        
        Error::singleton();                                    // obsluga bledow Error

        Cache::singleton();                                    // obsluga cache (APC, Memcached, etc)

        Session::singleton();                                  // obsluga sesji
        
        Db::singleton();
        
        Db::$FRDb = new DbMysqli(                              // obsluga bazy danych
                Config::DBFR_DbHost,
                Config::DBFR_DbPort,
                Config::DBFR_DbName,
                Config::DBFR_DbUser,
                Config::DBFR_DbPass,
                Config::DBFR_DbCharset,
                Config::DBFR_DbNames,
                Config::DBFR_DbTimezone,
                Config::DBFR_DbClFlag
                );
        
        Dictionary::singleton();                               // inicjalizacja slownika // przeniesione do _initWWW, _initCron
        
        switch($sTarget)
        {
            case 'WWW': // site www
                $this->_initWWW();
                break;
                
            case 'CRON':
                $this->_initCron();
                break;
        }
    }

    public function __destruct()
    {
        global $iMemoryStart;

        $fTime = Timer::display();
        $this->_saveStats($fTime);
        
        $fCCTime = ((isset(self::$aTimer['config+core'])) ? self::$aTimer['config+core'] : 0);
        
        $iUsedRAM = memory_get_peak_usage();
        
        if (
            ($fTime + $fCCTime > $this->_iMaxTime)
            || ($iUsedRAM - $iMemoryStart > $this->_iMaxRAM)
            || (Config::DEBUG_Program === TRUE && Config::$bShowDebug === TRUE)
            )
        {
            $aIncludedFiles = get_included_files(); sort($aIncludedFiles);
            
            $aDebug = array(
                'Router TemplateData' => Router::$aTemplateData,
                'Router FullAddress' => array(Router::$sAddress),
                'Router Address' => array(Router::$aAddress),
                //'Router Map' => Router::$aMapById,
                'FORM Data' => Form::$aFormData,
                'FORM Error' => Form::$aFormError,
                'POST' => (isset($_POST) ? $_POST : 'brak'),
                'GET' => (isset($_GET) ? $_GET : 'brak'),
                'SESSION' => $_SESSION,
                'wgrane obiekty' => self::$_aLoadedClasses,
                //'queries' => self::$oDBShop->getQueriesHistory(),
                'queries' => Db::$FRDb->getQueriesHistory(),
                //'backtrace' => debug_backtrace(),
                //'ilosc elementow' => ElementView::$iObjectCounter, // uruchamiac tylko w potrzebie, gdyz z crona wywala bledy bo nie ma deklaracji klasy
                //'objects' => array(self::$oDBShop),
                'wersja php' => phpversion(),
                'cache' => ((Config::CACHE_Enabled) ? Cache::getInfo() : 'no cache'),
                //'cache keys' => Cache::$aKeys,
                'konfiguracja' => Config::$aCfg,
                'dane serwera' => $_SERVER,
                'wgrane pliki' => $aIncludedFiles,
                'wgrane css i js' => array(HtmlView::$sCss, HtmlView::$sJs),
                'program timer' => self::$aTimer,
                'reczne' => self::$aDebugData,
                'pamiec start' => Lib::sizer($iMemoryStart),
                'pamiec end' => Lib::sizer($iUsedRAM),
                'pamiec zuzyta' => Lib::sizer($iUsedRAM - $iMemoryStart),
                'czas generacji' => ($fTime + $fCCTime)
            );
        }
        
        if (Config::DEBUG_Program === TRUE && Config::$bShowDebug === TRUE)
        {
            // zapisujemy staty generacji
            if (Config::CACHE_Enabled == FALSE || Config::CACHE_Engine == 'INTERNAL')
            {
                $sQueryInsert = "INSERT INTO ___tmp_generation_time (url, internal_time, internal_counter) VALUES (?,?,?) ON DUPLICATE KEY UPDATE internal_time = internal_time + ?, internal_counter = internal_counter + 1";
                $sQuerySelect = "SELECT internal_time/internal_counter FROM ___tmp_generation_time WHERE url=?";
            }
            else if (Config::CACHE_Enabled == TRUE || Config::CACHE_Engine == 'APC')
            {
                $sQueryInsert = "INSERT INTO ___tmp_generation_time (url, apc_time, apc_counter) VALUES (?,?,?) ON DUPLICATE KEY UPDATE apc_time = apc_time + ?, apc_counter = apc_counter + 1";
                $sQuerySelect = "SELECT apc_time/apc_counter FROM ___tmp_generation_time WHERE url=?";
            }
            Db::$FRDb->sqlTransactionBegin();
            Db::$FRDb->sqlExec($sQueryInsert, array(Router::$sAddress, ($fTime + $fCCTime), 1, ($fTime + $fCCTime)));
            Db::$FRDb->sqlTransactionCommit();
            
            $aDebug['sredni czas generacji'] = Db::$FRDb->sqlOne($sQuerySelect, array(Router::$sAddress));
            
            $sDebug = '<hr/ style="float:none; clear:both;">'
                .'<span style="color:red;font-size:14px;font-weight:bold;">DEBUG</span><br/>'
                .'<div id="debugd" style="height:400px; overflow:auto; font:10px verdana; float:none; clear:both;background-color: #fff;">'
                .'<pre>'
                .htmlspecialchars(print_r($aDebug , TRUE))
                .'</pre>'
                .'</div>'."\r\n";

            echo $sDebug;
        }
        
        Db::$FRDb->saveQueriesLog();
        
        Error::show();
    }
    
    
    /*
    // Metody prywatne, protected
    */

    
    private function _loadConfig()
    {
        $sPath = dirname(__FILE__).'/';
        
        self::loadClass('Config', $sPath);
        Config::setConfig();
    }
    
    private function _loadCore()
    {
        self::loadClass('Autoloader');
        
        new Autoloader();
    }
    
    private function _loadMVC()
    {
        self::loadClass('Model', Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineMVC);
        self::loadClass('Controller', Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineMVC);
    }

    private function _saveStats($p_fTime = 0.00000)
    {

    }

    private function _initWWW()
    {
        new Router();
        
        Form::singleton();            // obsluga formularzy i _POST
        
        $this->_loadMVC();            // ladujemy podstawowe klasy kontrolera i modelu
        
        Admin::singleton();           // obsluga admina (system cms)
        Customer::singleton();        // obsluga klienta (konto klienta)
        
        $this->_initMVC();            // ladujemy kontroler widoku i widok z elementami
    }
    
    private function _initMVC()
    {
        if (strlen(Router::$aTemplateData['engine_controller']) > 0)
        {
            $sViewObject = '';

            $sControllerObject = Router::$aTemplateData['engine_controller'].'Controller';

            if (strlen(Router::$aTemplateData['engine_view']) > 0)
            {
                $sViewObject = Router::$aTemplateData['engine_view'].'View';
            }

            new $sControllerObject(Router::$aTemplateData['controller_action'], $sViewObject);
        }
    }
    
    private function _initCron()
    {
        new Router(TRUE);             // obsluga adresu
        
        Router::forceFullAddress();   // wymuszamy zawsze pelne adresy
        
        $this->_loadMVC();            // ladujemy podstawowe klasy kontrolera i modelu
    }
    
    
    /*
    // Metody publiczne
    */


    public static function setClassLoaded($p_sClassName)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0)
        {
            self::$_aLoadedClasses[$sClassName] = $sClassName;
        }
    }

    public static function getClassLoaded($p_sClassName)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0 && isset(self::$_aLoadedClasses[$sClassName]))
        {
            return (self::$_aLoadedClasses[$sClassName]);
        }

        return FALSE;
    }

    public static function loadClass($p_sClassName, $p_sPath = NULL)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0)
        {
            $sPath = trim((isset($p_sPath) && $p_sPath != NULL) ? ((string)($p_sPath)) : Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineLibs);

            $sClassFilePath = strtolower($sPath.$sClassName.'.class.php');
            
            try
            {
                require_once($sClassFilePath);
            }
            catch (Exception $e)
            {
                Error::save('f100', 'Class '.$sClassFilePath.' not found', __FILE__, __LINE__);
                
                die();
            }
            
            self::setClassLoaded($sClassName);
            
            return TRUE;
        }
        else
        {
            die('Error - class missing');
        }

        return FALSE;
    }

    public static function loadElement($p_sElementName)
    {
        self::$_aLoadedElements[$p_sElementName] = $p_sElementName;
    }
}
?>
