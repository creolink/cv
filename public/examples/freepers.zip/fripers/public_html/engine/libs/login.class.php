<?php
/**
 *
 * Login - logowanie, sprawdzenie czy klient / user / admin jest zalogowany
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class Login extends Singleton
{
    /*
    // Deklaracje pol klasy
    */


    protected static $_sPassword = '';            // haslo zaszyfrowane
    
    private static $_sHashKey = '12312313132';    // klucz szyfrujacy


    /*
    // Konstruktor i destruktor
    */


    protected function __construct()
    {
        if (!self::_getLoggedSessionData())
        {
            if (isset($_COOKIE[Config::SessionName]) && $_COOKIE[Config::SessionName] != '') // logowanie z zapisanych ciastek
            {
                // czytamy ciastka czy jest zalogowany
                if (!self::_cookie())
                {
                    // logowanie z facebooka
                    static::_facebook();
                }
            }
        }
    }

    public function __destruct() {}


    /*
    // Metody prywatne
    */


    private static function _getLoggedSessionData()
    {

    }
    
    // metoda ustawia dane uzytkownika (po sprawdzeniu czy jest zalogowany)
    private static function _set($p_sLogin = NULL, $p_sPassword = NULL, $p_sPasswordOld = NULL)
    {
        $sLogin = trim((string)($p_sLogin));
        $sPassword = trim((string)($p_sPassword));
        $sPasswordOld = trim((string)($p_sPasswordOld));
        
        if($sLogin && $sPassword && strlen($sLogin) > 0 && strlen($sPassword) > 0 && ($aUserData = static::_get(NULL, $sLogin, $sPassword, TRUE, $sPasswordOld)))
        {
            static::$aData = $aUserData;

            return ($aUserData['UserId']);
        }
        
        return FALSE;
    }
    
    private static function _login($p_sLogin, $p_sPassword, $p_bEncode = TRUE)
    {

    }
    
    protected static function _cookie()
    {

    }
    
    protected static function _reLogin($p_sLogin, $p_sPassword)
    {

    }

    protected static function _encode($p_sValue)
    {

    }
    
    protected static function _decode($p_sValue)
    {

    }

    
    /*
    // Metody publiczne
    */
    
    
    public static function logout()
    {
        if (static::$bLogged || static::$iId > 0)
        {
            static::$bLogged = 0;
            static::$iId = 0;
            static::$aUserRights = array();

            return TRUE;
        }
        
        return FALSE;
    }

    public static function login($p_sLogin = '', $p_sPassword = '')
    {

    }
    
    public static function logged()
    {
        if (static::$bLogged && static::$iId > 0)
        {
            return (static::$iId);
        }
        
        return FALSE;
    }
}
?>
