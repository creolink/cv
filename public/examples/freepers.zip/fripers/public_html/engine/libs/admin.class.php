<?php
/**
 *
 * Admin - logowanie administratora do cms, obsluga adminow
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class Admin extends Login
{
    /*
    // Deklaracje pol klasy
    */


    protected static $_sSess = 'xxxx';             // nazwa sesji do logowania
    
    public static $aData = array();                // dane zalogowanego
    
    public static $bLogged;                        // flaga zalogowania
    public static $iId;                            // id uzytkownika
    public static $aUserRights = array();          // uprawnienia uzytkownika
    

    /*
    // Konstruktor i destruktor
    */


    


    /*
    // Metody prywatne
    */


    // metoda sprawdza login / haslo pracownika (sha-512)
    protected static function _get($p_iId = 0, $p_sLogin = '', $p_sPassword = '', $p_bIsActive = TRUE)
    {
        $iId = ((int)($p_iId));
        $sLogin = trim((string)($p_sLogin));
        $sPassword = trim((string)($p_sPassword)); // zaszyfrowane juz haslo
        $bIsActive = ((bool)($p_bIsActive));
        
        $sQuery = "";
        
        $aParams = array();
        if ($iId > 0) { $aParams[] = $iId; }
        if (strlen($sLogin) > 0) { $aParams[] = $sLogin; }
        if (strlen($sPassword) > 0) { $aParams[] = $sPassword; }

        if($aUserData = Db::$FRDb->sqlRow($sQuery, $aParams))
        {
            self::$_sPassword = $aUserData['UserPassword'];
            
            return ($aUserData);
        }

        return FALSE;
    }
    
    protected static function _saveLogin()
    {
        Db::$FRDb->sqlExec("UPDATE admins SET login_date = ? WHERE id = ?", array(time(), self::$aData['UserId']));
    }
    
    protected static function _facebook()
    {
        return FALSE;
    }

    
    /*
    // Metody publiczne
    */
    

}
?>
