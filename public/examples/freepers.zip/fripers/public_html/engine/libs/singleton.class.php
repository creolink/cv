<?php
/**
 *
 * Obsluga singleton w obiektach
 *
 * @package CreoEngine
 * @author CreoLink.pl - Jakub Luczynski, jakub.luczynski@gmail.com, jakub.luczynski@creolink.pl
 *
 * @version 2.0
 * @copyright (c) 2013 - 2014 Jakub Luczynski, CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
abstract class Singleton
{
    /*
    // Deklaracje pol klasy
    */
    
    
    
    
    
    /*
    // Konstruktor i destruktor
    */
    
    
    protected function __construct() {}
    
    protected function __destruct() {}
    
    
    /*
    // Metody prywatne, protected
    */
    
    
    final protected function __clone()
    {
        trigger_error( 'Clone is not allowed.', E_USER_ERROR);
    }
    
    
    /*
    // Metody publiczne
    */
    
    
    final public static function singleton()
    {
        static $_oInstance = NULL;

        return $_oInstance ?: $_oInstance = new static();
    }
}
?>
